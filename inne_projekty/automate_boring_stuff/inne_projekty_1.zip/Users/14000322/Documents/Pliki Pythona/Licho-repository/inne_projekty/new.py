import sqlite3

db = sqlite3.connect('data/mydb')
db.close()