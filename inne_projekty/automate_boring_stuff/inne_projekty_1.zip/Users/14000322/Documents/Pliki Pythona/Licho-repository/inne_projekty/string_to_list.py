# -*- coding: utf-8 -*-
"""
Created on Sat Sep 16 18:36:46 2017

@author: Leszek
"""

string = '''Close your eyes and I'll kiss you
Tomorrow I'll miss you
Remember I'll always be true
And then while I'm away
I'll write home every day
And I'll send all my loving to you

I'll pretend that I'm kissing
The lips I am missing
And hope that my dreams will come true
And then while I'm away
I'll write home every day
And I'll send all my loving to you

All my loving I will send to you
All my loving, darling I'll be true

Close your eyes and I'll kiss you
Tomorrow I'll miss you
Remember I'll always be true
And then while I'm away
I'll write home every day
And I'll send all my loving to you

All my loving I will send to you
All my loving, darling I'll be true
All my loving, all my loving ooh
All my loving I will send to you'''

list = string.split()
print(list)
