# -*- coding: utf-8 -*-
"""
Created on Sun Aug  6 10:25:40 2017

@author: Leszek
"""
# examples of print() and input() functions
print('What do you get when you cross a snowman with a vampire?')
input()
print('Frostbite!')
print()
print('What do dentists call an astronaut\'s cavity?')
input()
print('A black hole')
print()
print('Knock knock.')
input()
print("Who's there?")
input()
print('Interrupting cow.')
input()
print('Interrupting cow wh', end='')
print('-MOO!')